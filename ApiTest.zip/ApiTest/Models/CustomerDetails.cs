﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ApiTest.Models
{
    public class CustomerDetails
    {
        public string FullName { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string CurrentBank { get; set; }
        public string DocumentType { get; set; }
        public string DocumentNumber { get; set; }
        public string IsVerified { get; set; }
        public string VerifiedBy { get; set; }
        public string ValidTill { get; set; }
    }
}
