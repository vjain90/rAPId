﻿using ApiTest.Models;
using Microsoft.IdentityModel.Protocols;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;

namespace ApiTest.Services
{
    public class CustomerDetailsRepository
    {
        public CustomerDetails[] GetAllCustomerDetails()
        {
            DataTable dtExcel = ReadDataFromSource.ReadAsDataTable("Customer Details.xlsx");

            CustomerDetails[] customerDetails = new CustomerDetails[dtExcel.Rows.Count];
            int index = 0;

            foreach (DataRow row in dtExcel.Rows)
            {
                customerDetails[index] = new CustomerDetails();
                customerDetails[index].FullName = row["CustomerName"] == System.DBNull.Value ? string.Empty : (string)row["CustomerName"];
                customerDetails[index].Email = row["Email"] == System.DBNull.Value ? string.Empty : (string)row["Email"];
                customerDetails[index].Phone = row["Phone"] == System.DBNull.Value ? string.Empty : (string)row["Phone"];
                customerDetails[index].CurrentBank = row["Current Bank"] == System.DBNull.Value ? string.Empty : (string)row["Current Bank"];
                customerDetails[index].DocumentType = row["Document Type"] == System.DBNull.Value ? string.Empty : (string)row["Document Type"];
                customerDetails[index].DocumentNumber = row["Document Number"] == System.DBNull.Value ? string.Empty : (string)row["Document Number"];
                customerDetails[index].IsVerified = row["Is Verified"] == System.DBNull.Value ? string.Empty : (string)row["Is Verified"];
                customerDetails[index].VerifiedBy = row["Verified By"] == System.DBNull.Value ? string.Empty : (string)row["Verified By"];
                customerDetails[index].ValidTill = row["Valid Till"] == System.DBNull.Value ? string.Empty : (string)row["Valid Till"];

                index++;
            }

            return customerDetails;
        }

        public CustomerDetails[] GetCustomerDetailsByName(string name)
        {
            DataTable dtExcel = ReadDataFromSource.ReadAsDataTable("Customer Details.xlsx");
            //var filteredRecords = dtExcel.AsEnumerable().Where(e => e.Field<string>("CustomerName").ToLower() == name.ToLower()).ToList();
            var filteredRecords = dtExcel.Select("CustomerName = '" + name.ToLower() + "'");
            CustomerDetails[] customerDetails = new CustomerDetails[filteredRecords.Count()];
            int index = 0;

            foreach (DataRow row in filteredRecords)
            {
                if (((string)row["CustomerName"]).ToLower() == name.ToLower())
                {
                    customerDetails[index] = new CustomerDetails();
                    customerDetails[index].FullName = row["CustomerName"] == System.DBNull.Value ? string.Empty : (string)row["CustomerName"];
                    customerDetails[index].Email = row["Email"] == System.DBNull.Value ? string.Empty : (string)row["Email"];
                    customerDetails[index].Phone = row["Phone"] == System.DBNull.Value ? string.Empty : (string)row["Phone"];
                    customerDetails[index].CurrentBank = row["Current Bank"] == System.DBNull.Value ? string.Empty : (string)row["Current Bank"];
                    customerDetails[index].DocumentType = row["Document Type"] == System.DBNull.Value ? string.Empty : (string)row["Document Type"];
                    customerDetails[index].DocumentNumber = row["Document Number"] == System.DBNull.Value ? string.Empty : (string)row["Document Number"];
                    customerDetails[index].IsVerified = row["Is Verified"] == System.DBNull.Value ? string.Empty : (string)row["Is Verified"];
                    customerDetails[index].VerifiedBy = row["Verified By"] == System.DBNull.Value ? string.Empty : (string)row["Verified By"];
                    customerDetails[index].ValidTill = row["Valid Till"] == System.DBNull.Value ? string.Empty : (string)row["Valid Till"];

                    index++;
                }
            }

            return customerDetails;
        }

        public CustomerDetails[] GetCustomerDetailsByEmail(string email)
        {
            DataTable dtExcel = ReadDataFromSource.ReadAsDataTable("Customer Details.xlsx");
            var filteredRecords = dtExcel.Select("Email = '" + email.ToLower() + "'");

            CustomerDetails[] customerDetails = new CustomerDetails[filteredRecords.Count()];
            int index = 0;

            foreach (DataRow row in filteredRecords)
            {
                if (((string)row["Email"]).ToLower() == email.ToLower())
                {
                    customerDetails[index] = new CustomerDetails();
                    customerDetails[index].FullName = row["CustomerName"] == System.DBNull.Value ? string.Empty : (string)row["CustomerName"];
                    customerDetails[index].Email = row["Email"] == System.DBNull.Value ? string.Empty : (string)row["Email"];
                    customerDetails[index].Phone = row["Phone"] == System.DBNull.Value ? string.Empty : (string)row["Phone"];
                    customerDetails[index].CurrentBank = row["Current Bank"] == System.DBNull.Value ? string.Empty : (string)row["Current Bank"];
                    customerDetails[index].DocumentType = row["Document Type"] == System.DBNull.Value ? string.Empty : (string)row["Document Type"];
                    customerDetails[index].DocumentNumber = row["Document Number"] == System.DBNull.Value ? string.Empty : (string)row["Document Number"];
                    customerDetails[index].IsVerified = row["Is Verified"] == System.DBNull.Value ? string.Empty : (string)row["Is Verified"];
                    customerDetails[index].VerifiedBy = row["Verified By"] == System.DBNull.Value ? string.Empty : (string)row["Verified By"];
                    customerDetails[index].ValidTill = row["Valid Till"] == System.DBNull.Value ? string.Empty : (string)row["Valid Till"];

                    index++;
                }
            }

            return customerDetails;
        }
    }
}
