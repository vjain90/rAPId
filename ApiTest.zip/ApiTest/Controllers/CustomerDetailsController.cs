﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ApiTest.Models;
using ApiTest.Services;
using Microsoft.AspNetCore.Mvc;

namespace ApiTest.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerDetailsController : ControllerBase
    {
        private CustomerDetailsRepository customerDetailsRepository;

        public CustomerDetailsController()
        {
            this.customerDetailsRepository = new CustomerDetailsRepository();
        }

        // api/customerdetails/customername?name=xyz
        [HttpGet("customername")]
        public CustomerDetails[] GetCustomerByName(string name)
        {
            return customerDetailsRepository.GetCustomerDetailsByName(name);
        }

        // api/customerdetails/email?email=abc@xyz
        [HttpGet("email")]
        public CustomerDetails[] GetCustomerByEmail(string email)
        {
            return customerDetailsRepository.GetCustomerDetailsByEmail(email);
        }

        [HttpGet]
        public CustomerDetails[] Get()
        {
            return customerDetailsRepository.GetAllCustomerDetails();
        }

        //// POST api/customerdetails
        //public void Post([FromBody] string value)
        //{
        //}

        //// PUT api/customerdetails/5
        //public void Put(int id, [FromBody] string value)
        //{
        //}

        //// DELETE api/customerdetails/5
        //public void Delete(int id)
        //{
        //}
    }
}
